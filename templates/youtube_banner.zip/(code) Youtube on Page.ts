export class Horizontal {
  position: string;
  label: string;
}

export class Width {
    width:number;
    label: string;
}
export class Height {
height:number;
label:string;
}
export class YoutubeVideo implements CampaignTemplateComponent {

@markdown(`
---

###### ??  Add Youtube embedded URL
`)

@title("URL only, without quotation marks")
  video: String = "https://www.youtube.com/embed/tIp251KCz6k"

@title("Height")
@units ("px")
height: Number = 315


@title("Width")
@units ("px")
width: Number = 560
;

@title("Horizontal Position")
  @options([
      {position: "left", label: "Left"},
      {position: "center", label: "Center"},
      {position: "right", label: "Right"}
  ])
  horizontal: Horizontal = {position: "center", label: "Center"};
    
    run(context: CampaignComponentContext) {
        return {};
    }

}

