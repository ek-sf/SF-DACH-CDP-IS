export class EventType {
    label: string;
    name: string;
}

export class BannerWithCTATemplate implements CampaignTemplateComponent {

    @title("Meta Event Type")
    @subtitle("Choose Meta standard event") 
    @options([
        { label: "Add Payment Info", name: "AddPaymentInfo" },
        { label: "Add To Cart", name: "AddToCart" },
        { label: "Add To Wishlist", name: "AddToWishlist" },
        { label: "Complete Registration", name: "CompleteRegistration" },
        { label: "Contact", name: "Contact" },
        { label: "Customize Product", name: "CustomizeProduct" },
        { label: "Donate", name: "Donate" },
        { label: "Find Location", name: "FindLocation" },
        { label: "Initiate Checkout", name: "InitiateCheckout" },
        { label: "Lead", name: "Lead" },
        { label: "Purchase", name: "Purchase" },
        { label: "Schedule", name: "Schedule" },
        { label: "Search", name: "Search" },
        { label: "Start Trial", name: "StartTrial" },
        { label: "Submit Application", name: "SubmitApplication" },
        { label: "Subscribe", name: "Subscribe" },
        { label: "View Content", name: "ViewContent" }
    ])
    meta_event: EventType = { label: "Add Payment Info", name: "AddPaymentInfo" };

    run(context: CampaignComponentContext) {
        let segments = [];
        context.user.segmentMembership.forEach(e => segments.push(e.segmentName));

        return {segments};
    }

}
