export class StyleField {
    label: string;
    className: string;
}
export class ABC_Brand {
  brand: string;
  label: string;
}
export class ExitIntentPopupWithEmailCapture implements CampaignTemplateComponent {

    @header("Pop-Up Type")

    lightbox: boolean = true;

    @title("Choose Your ABC Brand")
    @options([
        { brand: "ABC Retail", label: "ABC Retail" },
        { brand: "ABC Cloud", label: "ABC Cloud" },
        { brand: "ABC Manufacturing", label: "ABC Manufacturing" },
        { brand: "ABC Auto", label: "ABC Auto" },
        { brand: "ABC Comms", label: "ABC Comms" },
        { brand: "ABC Travel", label: "ABC Travel" },
        { brand: "ABC Consumer Health", label: "ABC Consumer Health" },
        { brand: "ABC Medical", label: "ABC Medical" },
        { brand: "ABC Energy", label: "ABC Energy" },
        { brand: "ABC Football", label: "ABC Football" },
        { brand: "ABC Bank", label: "ABC Bank" },
        { brand: "ABC Insurance", label: "ABC Insurance" },
        { brand: "ABC NGO", label: "ABC NGO" },
    ])
    myBrand: ABC_Brand;
    
    @title("Background Image URL")
    imageUrl: string = "https://cdn.evergage.com/evergage-content/nto/nto_footwear.jpg";

    @subtitle("Define header and subheader text styling.")
    @options([
        { label: "Dark on Light", className: "evg-dark-on-light" },
        { label: "Light on Dark", className: "evg-light-on-dark" }
    ])
    style: StyleField = { label: "Dark on Light", className: "evg-dark-on-light" };

    header: string = "Header Text";

    @subtitle("Optional text field")
    subheader: string = "Subheader Text";

    @title("CTA Text")
    ctaText: string = "Call To Action";

    @title("Opt-Out Text")
    @subtitle("Clicking this text closes the pop-up.")
    optOutText: string = "No Thanks";

    @title("Confirmation Screen Header")
    @subtitle("Text appears upon successful email submission. Click CTA to preview.")
    confirmationHeader: string = "Confirmation Header Text";

    @title("Confirmation Screen Subheader")
    @subtitle("Optional text field")
    confirmationSubheader: string = "Confirmation Subheader Text";

    

    run(context: CampaignComponentContext) {
        return {};
    }

}
