export class BannerWithCTATemplate implements CampaignTemplateComponent {

    run(context: CampaignComponentContext) {
        return {};
    }

}
