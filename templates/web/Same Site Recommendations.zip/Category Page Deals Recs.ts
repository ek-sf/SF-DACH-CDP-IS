import { RecommendationsConfig, recommend } from "recs";
export class EinsteinProductRecsTemplate implements CampaignTemplateComponent {
    FinalProductsReturned : number = 1;
     @hidden(true)
    maximumNumberOfProducts: number = 12;
    @title("Recommendation 1")
    recsConfig1: RecommendationsConfig = new RecommendationsConfig().restrictItemType("Product").restrictMaxResults(this.maximumNumberOfProducts);
    @title("Recommendation 2")
    recsConfig2: RecommendationsConfig = new RecommendationsConfig().restrictItemType("Product").restrictMaxResults(this.maximumNumberOfProducts);
    run(context: CampaignComponentContext) {
        this.recsConfig1.maxResults = this.maximumNumberOfProducts;
        this.recsConfig2.maxResults = this.maximumNumberOfProducts;
        return {
            itemType: this.recsConfig1.itemType,
            products1: recommend(context, this.recsConfig1),
            products2: recommend(context, this.recsConfig2)
        };
    }
}