import { SurveyReference, SurveyReferenceLookup } from "surveys";

export class BoxShadow {
  boxShadow: boolean;
  label: string;
}

export class TriggerScrollPercentage {
  amount: string;
  secondProperty: number;
  label: string;
}

export class PopUpDirection {
  direction: string;
  label: string;
}

export class BgLayer {
  bgLayer: boolean;
  label: string;
}

export class SurveyTemplate implements CampaignTemplateComponent {
@markdown(`
**Survey Popup Template**  
[help docs](https://is-template-guide.herokuapp.com/docs/build/en/docs/pop-up/survey-popup/)
`)

    @title("Survey Type")
    @subtitle("? Pick up your survey created on Catalog > Surveys on the Interaction Studio UI.")
    @lookupOptions(() => new SurveyReferenceLookup())
    surveyReference: SurveyReference;

@markdown(`
---

###### ?? Trigger
`)

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Trigger Type")
  triggerType: "DOM Ready" | "Exit" | "Inactive" | "Scroll" = "DOM Ready" ;

  @shownIf(this, (self) => self.triggerType == "DOM Ready" && !!self.surveyReference)
  @title("Delay Time")
  @units('seconds')
  @optional(true)
  loadTriggerDelay: number = 3;

  @shownIf(this, (self) => self.triggerType == "Scroll" && !!self.surveyReference)
  @title("Scroll")
  @units('%')
  @options([
      {amount: "10", secondProperty: 1, label: "10%  "},
      {amount: "20", secondProperty: 2, label: "20%  "},
      {amount: "30", secondProperty: 3, label: "30%  "},
      {amount: "40", secondProperty: 4, label: "40%  "},
      {amount: "50", secondProperty: 5, label: "50%  "},
      {amount: "60", secondProperty: 6, label: "60%  "},
      {amount: "70", secondProperty: 7, label: "70%  "},
      {amount: "80", secondProperty: 8, label: "80%  "},
      {amount: "90", secondProperty: 9, label: "90%  "},
      {amount: "100", secondProperty: 10, label: "100%   "},
  ])
  triggerScrollPercentage: TriggerScrollPercentage = {amount: "50%  ", secondProperty: 5, label: "50%"};

  @shownIf(this, (self) => self.triggerType == "Exit" && !!self.surveyReference)
  @title("Time to wait until the popup appears")
  @units('seconds')
  @optional(true)
  triggerDelay: number = 5;

  @shownIf(this, (self) => self.triggerType == "Inactive" && !!self.surveyReference)
  @title("Inactive Time to wait until the popup appears")
  @units('seconds')
  @optional(true)
  triggerSec: number = 1;

@markdown(`
---

###### ?? Popup Style
`)

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Header Image")
  logoUrl: string = 'https://c1.sfdcstatic.com/content/dam/sfdc-docs/www/logos/logo-salesforce.svg';

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Width")
  @units('px')
  maxWidth: number = 310;

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Border Radius")
  @units('px')
  borderRadius = 6;

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Background Color")
  bgColor: Color = {
      hex:"#ffffff",
      r:255,
      g:255,
      b:255,
      a:1
  };

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Close Button Color")
  closeBtnColor: Color = {
      hex:"#ffffff",
      r:255,
      g:255,
      b:255,
      a:1
  };

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Shadow")
  @options([
      {boxShadow: true, label: "Enabled?????"},
      {boxShadow: false, label: "Disabled?????"}
  ])
  boxShadow: BoxShadow = {boxShadow: true, label: "Enabled?????"};

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Border Top Color of the Completed Popup")
  lastBorderColor: Color = {
      hex:"#f43f5e",
      r:244,
      g:63,
      b:94,
      a:1
  };

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Animation Direction")
  @options([
      {direction: 'vertical', label: "Vertical   "},
      {direction: 'horizontal', label: "Horizontal   "}
  ])
  popupDirection: PopUpDirection = {direction: 'horizontal', label: "Horizontal   "};

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Background Layer")
  @options([
      {bgLayer: true, label: "Enabled    "},
      {bgLayer: false, label: "Disabled    "}
  ])
  bgLayer: BgLayer = {bgLayer: true, label: "Enabled    "};

  @title("Background Layer Color")
  @shownIf(this, (self) => self.bgLayer.bgLayer && !!self.surveyReference)
  bgLayerColor: Color = {
      hex:"#000000",
      r:0,
      g:0,
      b:0,
      a:0.6
  };

@markdown(`
---

###### ?? Text Style
`)

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Question Title Font Size")
  @units('px')
  questionTextFontSize: number = 18;

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Question Title Font Color")
  questionTextFontColor: Color = {
      hex:"#000000",
      r:0,
      g:0,
      b:0,
      a:1
  };

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Question Item Font Color")
  questionItemTextFontColor: Color = {
      hex:"#000000",
      r:0,
      g:0,
      b:0,
      a:1
  };

@markdown(`
---

###### ?? Button Style
`)

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Button Font Size")
  @units('px')
  buttonTextFontSize: number = 12;

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Button Font Color")
  buttonTextFontColor: Color = {
      hex:"#ffffff",
      r:255,
      g:255,
      b:255,
      a:1
  };
  
  @shownIf(this, (self) => !!self.surveyReference)
  @title("Button Border Radius")
  @units('px')
  buttonRadius: number = 40;

  @shownIf(this, (self) => !!self.surveyReference)
  @title("Button Color")
  buttonBgColor: Color = {
      hex:"#f43f5e",
      r:85,
      g:85,
      b:85,
      a:1
  };

@markdown(`
---

###### ?? Text Content
`)
    @shownIf(this, (self) => !!self.surveyReference)
    @title("Text for Completed Popup")
    @richText(true)
    completeText: string = "Thank you for completing the survey!"
  
@markdown(`
---

###### ?? Event Name Prefix
`)

    @shownIf(this, (self) => !!self.surveyReference)
    @title("Event Name Prefix sent to IS")
    @subtitle('If you click the completed button in the survey, "[EVENT_NAME_PREFIX]_Complete_Survey" will be sent to IS.')
    eventName: string = 'SFDC';

    run(context: CampaignComponentContext) {
        const survey = context.services.surveys.getSurvey(this.surveyReference.id);
        return {
            survey: survey,
            triggerType: this.triggerType,
            triggerScrollPercentage: this.triggerScrollPercentage,
            triggerDelay: this.triggerDelay,
            triggerSec: this.triggerSec
        }
    }
}
