(function () {
 
  function buildBindId(context) {
    return `${context.campaign}:${context.experience}`;
  }

  function insertHeaderElem ($appendTarget, context) {
    const logo = Evergage.cashDom('<div class="is-logo-wrapper"><img style="max-width: 100%; max-height: 100px; display: block; margin: 10px auto auto;" src="' + context.logoUrl + '"></div>');
    $appendTarget.prepend(logo);
  }

  function insertElem ($appendTarget) {
    const popupWrapper = Evergage.cashDom('<div>').attr('class', 'is-popup-wrapper');
    $appendTarget.append(popupWrapper);
  }

  function insertCloseElem ($appendTarget, context) {
    const closeButton = Evergage.cashDom('<button>').attr({
      'class': 'is-popup-close',
      'aria-label': '???'
      });
    closeButton.append('<div class="is-popup-close__inner"><span class="is-popup-close__line"></span><span class="is-popup-close__line"></span>');
    $appendTarget.append(closeButton);
    Evergage.cashDom('.is-popup-close__line').css('background', 'rgba(' + context.closeBtnColor.r  + ',' + context.closeBtnColor.g + ',' + context.closeBtnColor.b + ',' + context.closeBtnColor.a + ')')
  }

  function handleOverlay (body, hasOverlay, overlayColor) {
    if (!hasOverlay) return;
    body.append('<div class="is-overlay" style="background: ' + 'rgba(' + overlayColor.r  + ',' + overlayColor.g + ',' + overlayColor.b + ',' + overlayColor.a + ')' + '"></div>');
  }

  // Campaign??????
  function apply(context, template) {
  
    function cb_apply(context) {    
      if (!context.survey) return;

      const POPUP_CLASS = '.is-popup-wrapper';
      if (!!document.querySelector(POPUP_CLASS)) return;

      const $body = Evergage.cashDom('body');
      const $survey = Evergage.cashDom(template(context).trim());
      insertElem($body);
      insertCloseElem(Evergage.cashDom(POPUP_CLASS), context);
      const $surveyElem =  Evergage.cashDom(POPUP_CLASS);
      const $closeBtn = Evergage.cashDom('.is-popup-close');

      async function render() {
        await Evergage.DisplayUtils.pageElementLoaded(POPUP_CLASS, 'body');
        await Evergage.Surveys.injectSurveyResourcesIntoPage();
        Survey.StylesManager.applyTheme('default');
        await Evergage.Surveys.renderSurvey(context.survey, $survey);
      }

      render()
        .then(() => {
          $surveyElem.append($survey);
          const baseElem = document.getElementById('evg-surveys');
          const maxWidth = getComputedStyle(baseElem).getPropertyValue('--maxWidth');
          $surveyElem.css('max-width', maxWidth);
          insertHeaderElem(Evergage.cashDom('.sv_body'), context);

          // ??????
          handleOverlay($body, context.bgLayer.bgLayer, context.bgLayerColor);

          // ?????????????
          baseElem.classList.add('is-show');
          $closeBtn.on('click', function() {
            baseElem.classList.remove('is-show');
            Evergage.cashDom('.is-overlay').hide();
            Evergage.cashDom(this).remove();
          })

          Evergage.cashDom('body').on('click', '.sv_complete_btn', function(){
              Evergage.cashDom('.sv_completed_page').find('h3').html(context.completeText)
              const EVENT_NAME = 'Complete_Survey';
              const eventNamePrefix = context.eventName ? `${context.eventName}_` : '';
              Evergage.sendEvent({
                  action: `${eventNamePrefix}${EVENT_NAME}`,
                  user: context.userGroup,
              }) 
          });
        })
        .catch(err => console.error(err))
    }

     // ??????????
    switch (context.triggerType) {
      case "Exit":
        Evergage.DisplayUtils.bind(buildBindId(context)).pageExit(context.triggerDelay * 1000).then(() => {
          return cb_apply(context);
        });
      case "Inactive":
        Evergage.DisplayUtils.bind(buildBindId(context)).pageInactive(context.triggerSec * 1000).then(() => {
          return cb_apply(context);
        });
      case "Scroll":
        Evergage.DisplayUtils.bind(buildBindId(context)).pageScroll(context.triggerScrollPercentage / 100).then(() => {
          return cb_apply(context);
        });
      case "DOM Ready":
        setTimeout(() => {
          return cb_apply(context);
        }, context.loadTriggerDelay * 1000)
    }
  }

  function reset(context, template) {
    Evergage.DisplayUtils.unbind(buildBindId(context));
    Evergage.cashDom("#evg-survey").remove(); 
  }

  function control(context) { 
    console.log('control');
  }

  registerTemplate({
    apply: apply,
    reset: reset,
    control: control
  });

})();